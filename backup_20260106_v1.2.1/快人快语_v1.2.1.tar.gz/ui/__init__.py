# ui/__init__.py
# UI 模块初始化

from .settings_window import SettingsWindow

__all__ = [
    "SettingsWindow",
]
