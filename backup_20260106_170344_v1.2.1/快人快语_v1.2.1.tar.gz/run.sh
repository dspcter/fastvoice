#!/bin/bash
cd "$(dirname "$0")"
echo "正在启动快人快语..."
python3 main.py
